
import java.util.LinkedList;
import java.util.ArrayList;

public class StoringData {
	private int capacity; //array capacity for maximum number of spaces available.
	private int[] levels; //array for storing vehicles in/out per level in a garage
	LinkedList<Integer> spaces;
	
	
}
