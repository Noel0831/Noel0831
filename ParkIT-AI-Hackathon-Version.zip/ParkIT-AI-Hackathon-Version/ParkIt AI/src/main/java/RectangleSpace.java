

public class RectangleSpace {

}
