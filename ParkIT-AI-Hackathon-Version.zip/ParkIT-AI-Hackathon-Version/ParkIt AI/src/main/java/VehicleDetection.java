/*package main.java;

public class VehicleDetection {
	if(carIn()) {
		spots--;
	} else if(carOut()) {
		spots++;
	}
}
*/